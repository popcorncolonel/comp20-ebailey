// Express initialization
var express = require('express');
var app = express();
var http = require('http');

// Mongo initialization, setting up a connection to a MongoDB  (on Heroku or localhost)
var mongoUri = process.env.MONGOLAB_URI ||
process.env.MONGOHQ_URL ||
'mongodb://heroku_app31104049:hqumb4m5v4oporqq43hrca97f0@ds053130.mongolab.com:53130/heroku_app31104049';
var mongo = require('mongodb');

mongo.Db.connect(mongoUri, function (error, databaseConnection) {
        db = databaseConnection;
});


app.post('/sendLocation', function (request, response) {
        response.header('Access-Control-Allow-Origin', '*');
        response.header('Access-Control-Allow-Methods', 'GET,PUT,POST,OPTIONS');

        if (request.method === 'OPTIONS' || request.method === 'POST') {
        var headers = {};
        headers["Access-Control-Allow-Origin"] = "*";
        headers["Access-Control-Allow-Methods"] = "POST, GET, PUT, DELETE, OPTIONS";
        headers["Access-Control-Allow-Credentials"] = false;
        headers["Access-Control-Max-Age"] = '86400'; // 24 hours
        headers["Access-Control-Allow-Headers"] = "X-Requested-With, X-HTTP-Method-Override, Content-Type, Accept";
        body = ''
        request.on('data', function(data) {
            body += data;
        });
        request.on('end', function() {
            //response.writeHead(200);
            //response.end('i got dis: ' + body);
            params = body.split('&')
            var login = '';
            var lng = '';
            var lat = '';
            for (var i=0; i < 3; i++) {
                if (params[i].split('=')[0] == 'login')
                    login = params[i].split('=')[1];
                if (params[i].split('=')[0] == 'lng')
                    lng = params[i].split('=')[1];
                if (params[i].split('=')[0] == 'lat')
                    lat = params[i].split('=')[1];
            }
            if (login == '' || lat == '' || lng == '') {
            return;
            }

            entirelist = '';
            var created_at = new Date();
            db.collection('locations', function(err, collection) {
                if (err) {
                    return '[]';
                }
                if (collection) {
                    collection.insert({"login":login, "lat":lat, "lng":lng, "created_at":created_at}, function(){});
                    collection.find({"$query":{},"$orderby":{"created_at":-1}}).toArray(function(err, cursor) {
                        if (!err) {
                            charlist = JSON.stringify(cursor);
                            entirelist = '{"characters":[],"students":' + charlist + '}';
                            response.send(entirelist);
                            return;
                        } else {
                            response.send('[]');
                            return;
                        }
                    });
                }
            });
        });
        }
});

app.get('/locations.json', function (request, response) {
        response.header('Access-Control-Allow-Origin', '*');
        response.header('Access-Control-Allow-Methods', 'GET,PUT,POST,OPTIONS');
        response.set('Content-Type', 'text/json');
        var login = request.param('login') || '';
        if (login == '') {
            response.send('[]');
            return;
        }

        db.collection('locations', function(error, collection) {
            collection.find().toArray(function(err, cursor) {
                if (cursor.length == 0) {
                    response.end('[]');
                }
                if (!err) {
                    cursor = cursor.filter(function(x) {
                        return login == x['login'];
                    });
                    response.send(JSON.stringify(cursor));
                    return;
                } else {
                    response.send('[]');
                    return;
                }
            });
        });
});

app.get('/redline.json', function (request, response) {
        response.header('Access-Control-Allow-Origin', '*');
        response.header('Access-Control-Allow-Methods', 'GET,PUT,POST,OPTIONS');
        response.set('Content-Type', 'text/json');

        var options = {
          host: 'developer.mbta.com/lib/rthr',
          port:80, 
          path: '/red.json'
        };
        url = 'http://developer.mbta.com/lib/rthr/red.json';
        http.get(url, function(res) {
            var str = '';
            res.on('data', function (chunk) {
                str += chunk;
            });
            res.on('end', function () {
                response.end(str);
            });
        });
});

app.get('/', function (request, response) {
        response.header('Access-Control-Allow-Origin', '*');
        response.header('Access-Control-Allow-Methods', 'GET,PUT,POST,OPTIONS');
        response.set('Content-Type', 'text/html');

        db.collection('locations', function(error, collection) {
                collection.find({"$query":{},"$orderby":{"created_at":-1}}).toArray(function(err, cursor) {
                if (cursor.length == 0) {
                    response.end('[]');
                }
                if (!err) {
                    body = '';
                    cursor.forEach(function(entry) {
                        body += '<span style="font-weight:bold">';
                        body += entry['login'];
                        body += '</span> last checked in at ';
                        body += '<span style="font-weight:bold">';
                        body += entry['created_at'];
                        body += '</span>';
                        body += ' at the location (of the form (lat,lng)): (';
                        body += '<span style="font-weight:bold">';
                        body += entry['lat'];
                        body += ', ';
                        body += entry['lng'];
                        body += ')'
                        body += '</span>';
                        body += '!<br>';
                    });
                    response.send(body);
                    return;
                } else {
                    response.send('[]');
                    return;
                }
            });
        });

});

app.listen(process.env.PORT || 3000);

