**Identify what aspects of the work have been correctly implemented and what have not.**  
Everything has been implemented to the best of my knowledge.

**Identify anyone with whom you have collaborated or discussed the assignment.**  
I did not collaborate this assignment with anyone.

**Say approximately how many hours you have spent completing the assignment.**  
6

